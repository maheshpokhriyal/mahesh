#!/usr/bin/python3.0
import platform
import os
import subprocess
import sys
import os.path
import csv
import pandas as pd

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""
zn=os.popen("zoneadm list -vc|grep -v ID|awk '{print $1,$2,$3,$4,$5,$6}'").read()
with open("zone.txt","w") as wh:
    wh.write(zn)
wh.close()
col_names = ['ID', 'NAME', 'STATUS', 'PATH', 'BRAND', 'IP']
data = pd.read_csv(r'zone.txt', sep=' ', names=col_names, index_col=0, header=None)
data.to_csv('ZONE.csv')

df = pd.read_csv("ZONE.csv")
df.insert(0, column = "Hostname", value = hostname1)
df.head()
df.to_csv("CSV_OUTPUT_NEW_N/Solaris_Zone.csv", index=False)
