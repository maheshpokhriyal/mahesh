import os
import subprocess
import os.path
import psutil
import numpy as np
import pandas as pd
import csv
from collections import OrderedDict

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

v_phy=(""+str(psutil.cpu_count(logical=False)))
v_core=(""+str(psutil.cpu_count(logical=True)))
cpumodel = os.popen("/usr/sbin/prtdiag -l|grep Intel").read()


fields = ['Hostname', 'CPU Model', 'Physical Cores', 'Total Cores' ]
# data rows of csv file
rows = [[""+str(hostname1), (""+str(cpumodel)), ""+str(v_phy), ""+str(v_core) ]]

# name of csv file
filename = "CSV_OUTPUT_NEW_N/CPU_INFO.csv"

# writing to csv file
with open(filename, 'w') as csvfile:
    # creating a csv writer object
    csvwriter = csv.writer(csvfile)

    # writing the fields
    csvwriter.writerow(fields)

    # writing the data rows
    csvwriter.writerows(rows)
