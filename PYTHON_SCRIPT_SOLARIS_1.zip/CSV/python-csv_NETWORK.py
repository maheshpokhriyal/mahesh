import os
import subprocess
import os.path
import pandas as pd
import csv

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

nw=os.popen("ipadm show-addr|egrep -v 'v6|ADDROBJ'|awk '{print $1,$2,$3,$4}'").read()
with open("NETWORK.txt","w") as wh:
    wh.write(nw)
wh.close()
col_names = ['Interface Device', 'Class/Type', 'State', 'IP Address']
data = pd.read_csv(r'NETWORK.txt', sep=' ', names=col_names, index_col=0, header=None)
data.to_csv('Network1.csv')

df = pd.read_csv("Network1.csv")
df.insert(0, column = "Hostname", value = hostname1)
df.head()
df.to_csv("CSV_OUTPUT_NEW_N/NETWORK.csv", index=False)
