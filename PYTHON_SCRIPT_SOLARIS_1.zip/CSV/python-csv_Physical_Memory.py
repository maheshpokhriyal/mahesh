import os
import subprocess
import os.path
import psutil
import csv
import numpy as np
import pandas as pd
from collections import OrderedDict
svmem=psutil.virtual_memory()

def get_size(num):
    factor = 1024
    for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
        if num < factor:
            return "%3.1f %s" % (num, x)
        num /= factor

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""
tmem = ""+str(get_size(svmem.total))
amen = ""+str(get_size(svmem.available))
umem = ""+str(get_size(svmem.used))
per = ""+str(svmem.percent)

fields = ['Hostname', 'Total Memory', 'Available Memory', 'Used Memory', 'Percentage' ]
# data rows of csv file
rows = [[ ""+str(hostname1), ""+str(tmem), ""+str(amen), ""+str(umem), ""+str(per) ]]

# name of csv file
filename = "CSV_OUTPUT_NEW_N/Physical_Memory_INFO.csv"

# writing to csv file
with open(filename, 'w') as csvfile:
    # creating a csv writer object
    csvwriter = csv.writer(csvfile)

    # writing the fields
    csvwriter.writerow(fields)

    # writing the data rows
    csvwriter.writerows(rows)
