#!/usr/bin/python3.0
import psutil
import platform
import os
import subprocess
import sys
import re
import time
import getpass
import os.path
import datetime
import csv
from datetime import date

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

firewalls=os.popen("svcs -l firewall:default|grep -w state|awk '{print $2}'").read().splitlines()
for line in firewalls:
    fw=line.strip()

fd=os.popen("pfctl -s rules").read()

# field names  
fields = ['Hostname', 'Firewall Status', 'Firewalld Configuration' ]
# data rows of csv file
rows = [[""+str(hostname1), ""+str(fw), ""+str(fd)]] 

# name of csv file
filename = "CSV_OUTPUT_NEW_N/FIREWALL.csv"

# writing to csv file
with open(filename, 'w') as csvfile:
    # creating a csv writer object
    csvwriter = csv.writer(csvfile)

    # writing the fields
    csvwriter.writerow(fields)

    # writing the data rows
    csvwriter.writerows(rows)
