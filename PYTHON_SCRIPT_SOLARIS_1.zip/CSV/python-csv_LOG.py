#!/usr/bin/python3.0
import platform
import os
import subprocess
import sys
import re
import os.path
import csv
import pandas as pd

import csv

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

import pathlib
file = pathlib.Path("/var/adm/messages")
if file.exists ():
    m=os.popen('ls -lh /var/adm/messages|awk \'{print $9 ";" $6,$7,$8 ";" $5 ";" echo "Live Log File"}\'').read()
else:
    m="/var/adm/messages;File not exist; ; \n"
file = pathlib.Path("/var/adm/messages.*")
if file.exists ():
    m1=os.popen('ls -lh /var/adm/messages.*|awk \'{print $9 ";" $6,$7,$8 ";" $5 ";" echo "Archive Log File"}\'').read()
else:
    m1="/var/adm/messages.*;Archive File not exist ; ; \n"
with open("LOG.txt","w") as wh:
    wh.write(m+m1)
wh.close()

col_names = ['Log_File', 'Date', 'Size', 'File Type']
data = pd.read_csv(r'LOG.txt', sep=';', names=col_names, index_col=0, header=None)
data.to_csv('LOG.csv')

df = pd.read_csv("LOG.csv")
df.insert(0, column = "Hostname", value = hostname1)
df.head()
df.to_csv("CSV_OUTPUT_NEW_N/System_Log.csv", index=False)
