#!/usr/bin/python3.0
import psutil
import platform
import os
import subprocess
import sys
import re
import time
import getpass
import os.path
import datetime
import csv
import subprocess
import os
import os.path
from os import path
from pathlib import Path
from subprocess import Popen, PIPE
from datetime import date

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

ase = os.popen("pkginfo ase|awk '{print $2}'").read()
if len(ase) != 0:
    nacl_service=os.popen("su - nagios -c 'NaCl/NaCl -s 10.194.33.216'|grep -v Oracle").read()
    nacl=os.popen("su - nagios -c 'NaCl/NaCl -V'|grep NaCl|awk -F- '{print $1}'").read()
    ase = os.popen("pkginfo -l ase|egrep 'PKGINST|VERSION'").read()
    ase_service=os.popen("ps -eo,pid,comm|grep ase").read()
    # field names  
    fields = ['Hostname', 'CMF Nagios Agent', 'CMF Nagios Agent Status', 'ASE Agent', 'ASE Agent Status' ]
    # data rows of csv file
    rows = [[(""+str(hostname1)), (""+str(nacl)), (""+str(nacl_service)), (""+str(ase)), (""+str(ase_service))]] 

    # name of csv file
    filename = "CSV_OUTPUT_NEW_N/NAGIOS.csv"

    # writing to csv file
    with open(filename, 'w') as csvfile:
            # creating a csv writer object
            csvwriter = csv.writer(csvfile)

            # writing the fields
            csvwriter.writerow(fields)

            # writing the data rows
            csvwriter.writerows(rows)
else:
    print("atos-cmf-client-nacl package is not installed")
