#!/usr/bin/python3.0
import psutil
import platform
import os
import subprocess
import sys
import re
import time
import getpass
import os.path
import datetime
import socket
from collections import OrderedDict
from datetime import date


def get_size(bytes, suffix="B"):
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P"]:
        if bytes < factor:
            return "%3.1f %s" % (bytes, unit)
        bytes /= factor

############ OS ##############################
hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

OSV = os.popen("cat /etc/release|grep Oracle|grep -v Copyright").read()
hostname = socket.gethostname()
serial = subprocess.getoutput("prtdiag -v|awk '/Chassis Serial/{getline; getline; print}'")
hw = subprocess.getoutput("prtdiag |grep 'System Configuration'|awk -F: '{print $2}'")
kernel = subprocess.getoutput("pkg info kernel|grep Version|awk -F: '{print $2}'")
uname=platform.uname()


#### Processor #######

v_phy=(""+str(psutil.cpu_count(logical=False)))
v_core=(""+str(psutil.cpu_count(logical=True)))
#cpufreq = psutil.cpu_freq()
cpumodel=os.popen("prtdiag -l|grep Intel").read()

########### Disk Info ####################

partitions = psutil.disk_partitions()
for partition in partitions:
    s2=""+str(partition.mountpoint)+"\n"
    with open("FS.txt","a") as wh:
        wh.write(s2)
    wh.close()
f = open("FS.txt","r+")
disk=os.popen("cat FS.txt").read()
f.truncate(0)

###############################################################

f3=os.popen("zpool list -o name,size|grep rpool|awk '{print $2}'").read()

########### Memory ###################
svmem=psutil.virtual_memory()


import csv  
   
# field names  
fields = ['HostName', 'OS', 'Serial number', 'IP Address', 'OS Kernel', 'CPU core count', 'CPU speed (MHz)', 'Disk space (GB)', 'Mount Point', 'RAM' ]
# data rows of csv file
rows = [[(""+str(hostname1)), ""+str(OSV), ""+str(serial), ""+str(socket.gethostbyname(hostname)), ""+str(kernel), ""+str(v_phy), ""+str(cpumodel), ""+str(f3), ""+str(disk), (""+str(get_size(svmem.total)))]] 

# name of csv file
filename = "CSV_OUTPUT_NEW_N/Server_Info.csv"

# writing to csv file
with open(filename, 'w') as csvfile:
    # creating a csv writer object
    csvwriter = csv.writer(csvfile)

    # writing the fields
    csvwriter.writerow(fields)

    # writing the data rows
    csvwriter.writerows(rows)
