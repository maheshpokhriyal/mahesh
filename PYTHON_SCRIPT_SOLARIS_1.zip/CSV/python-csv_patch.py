#!/usr/bin/python3.0
import os
import subprocess
import os.path
import pandas as pd
import csv

hostname=subprocess.check_output('hostname',shell=True)
hostname1="" + hostname.decode().replace('\n',' ') + ""

patch = os.popen("grep -h PATCH_INFO_ /var/sadm/pkg/SUNW*/pkginfo | sed -e 's/From:.*//' |grep 2019 |head").read()
with open ("patch.txt","w") as wh:
    wh.write(patch)
p1 = os.popen("cat patch.txt|awk -F: '{print $1,$2}'").read()
col_names = [ 'Patch Details', 'Installed Date' ]
data = pd.read_csv(r'Patch.txt', sep=' ', names=col_names, index_col=0, header=None)
data.to_csv('Patch.csv')

df = pd.read_csv("Patch.csv")
df.insert(0, column = "Hostname", value = hostname1)
df.head()
df.to_csv("CSV_OUTPUT_NEW_N/PATCH.csv", index=False)
