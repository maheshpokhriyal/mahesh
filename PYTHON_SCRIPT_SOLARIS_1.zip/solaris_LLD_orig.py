# -*- coding: utf-8 -*-
# -*- coding: cp1252 -*-
#!/usr/bin/python3
import docx,socket
from docx import Document
import psutil
import platform 
import os
import subprocess
import sys
import re
import time
import getpass
import os.path
import datetime
import time
from collections import OrderedDict
from docx.enum.dml import MSO_THEME_COLOR_INDEX
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls
from datetime import date
from docx.oxml.ns import qn
from docx.oxml.shared import OxmlElement
from docx.shared import Inches, Pt
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.style import WD_STYLE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import pathlib
file = pathlib.Path("/root/template.docx")
if file.exists ():
    doc = docx.Document()
    doc_para = doc.add_paragraph()

    ## Define Color Shade function ##
    def shade_cells(cells, shade):
        for cell in cells:
            tcPr = cell._tc.get_or_add_tcPr()
            tcVAlign = OxmlElement("w:shd")
            tcVAlign.set(qn("w:fill"), shade)
            tcPr.append(tcVAlign)
    
    ## Define "hyperlink" function ##
    def add_hyperlink(paragraph, text, url):
        # This gets access to the document.xml.rels file and gets a new relation id value
        part = paragraph.part
        r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)

        # Create the w:hyperlink tag and add needed values
        hyperlink = docx.oxml.shared.OxmlElement('w:hyperlink')
        hyperlink.set(docx.oxml.shared.qn('r:id'), r_id, )

        # Create a w:r element and a new w:rPr element
        new_run = docx.oxml.shared.OxmlElement('w:r')
        rPr = docx.oxml.shared.OxmlElement('w:rPr')

        # Join all the xml elements together add add the required text to the w:r element
        new_run.append(rPr)
        new_run.text = text
        hyperlink.append(new_run)

        # Create a new Run object and add the hyperlink into it
        r = paragraph.add_run ()
        r._r.append (hyperlink)

        # A workaround for the lack of a hyperlink style (doesn't go purple after using the link)
        # Delete this if using a template that has the hyperlink style in it
        r.font.color.theme_color = MSO_THEME_COLOR_INDEX.HYPERLINK
        r.font.underline = True

        return hyperlink

    ## Defibe "size calculation" function ##
    def get_size(num):
        step_unit = 1024
        for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
            if num < step_unit:
                return "%3.1f %s" % (num, x)
            num /= step_unit
    print("Perform System Section")
    ### General Information ####
    doc.add_heading(' General information ')
    doc.add_heading(' Purpose ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The purpose of this document is to provide detailed technical guidance required to implement a new SuSE Linux Server in accordance with Atos Global Delivery standards and portfolio services. This document describes the requirements and recommendations for the configuration of an SuSE Linux Server managed by Atos.")

    doc.add_heading(' Audience ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This document is intended for SuSE Linux Server guidance tasked with implementing or migrating to a new solution. The blueprint assumes that the reader has reasonable grasp of SuSE Linux Enterprise Server operating system as well as familiarity with architecture principles including high availability and multi-tenancy.")

    doc.add_heading(' In Scope', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The scope of SuSE Linux Enterprise Server covers the following:")
    doc_para = doc.add_paragraph("Supported Operating Systems: SLES 11 and 12 ", style='List Bullet')
    doc_para = doc.add_paragraph("Selecting a technical solution to meet the required SLA", style='List Bullet')
    doc_para = doc.add_paragraph("Customizing the infrastructure to meet a solution needs and adhere best practices", style='List Bullet')
    doc_para = doc.add_paragraph("SuSE Linux Enterprise Server deployment", style='List Bullet')
    doc_para = doc.add_paragraph("Post-installation configuration and best practices in terms of security and performance", style='List Bullet')
    doc_para = doc.add_paragraph("Integration of an SuSE Linux Server with Atos tools (backup, monitoring, reporting, billing)", style='List Bullet')

    doc.add_heading(' Out of Scope', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The following areas are explicitly out of scope:")
    doc_para = doc.add_paragraph("Unsupported SLES versions", style='List Bullet')
    doc_para = doc.add_paragraph("Application management", style='List Bullet')
    doc_para = doc.add_paragraph("Anything not explicitly noted as in scope", style='List Bullet')


    doc.add_heading(' Glossary ', 2)
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n ")
    table = doc.add_table(rows=39, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True
	# populate header row -------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('Abbreviation / Term').bold = True
	#shade_cells([heading_cells[0]],"#0066A2")
    shade_cells([heading_cells[0]],"#0000FF")
    heading_cells[1].paragraphs[0].add_run('Description').bold = True
    shade_cells([heading_cells[1]],"#0000FF")

    row = table.rows[1]
    row.cells[0].text = "BS 7799"
    row.cells[1].text = 'Standard for Information Security Management'

    row = table.rows[2]
    row.cells[0].text = "ITIL"
    row.cells[1].text = 'Information Technology Infrastructure Library'

    row = table.rows[3]
    row.cells[0].text = "LDAP"
    row.cells[1].text = 'Lightweight Directory Access Protocol'

    row = table.rows[4]
    row.cells[0].text = "CMDB"
    row.cells[1].text = 'Configuration Management Database'

    row = table.rows[5]
    row.cells[0].text = "CPU"
    row.cells[1].text = 'Central Processing Unit'

    row = table.rows[6]
    row.cells[0].text = "DR"
    row.cells[1].text = 'Disaster Recovery'

    row = table.rows[7]
    row.cells[0].text = "ICMP"
    row.cells[1].text = 'Internet Control Message Protocol'

    row = table.rows[8]
    row.cells[0].text = "IPA"
    row.cells[1].text = 'Integrated Identity and Authentication'

    row = table.rows[9]
    row.cells[0].text = "HA"     
    row.cells[1].text = 'High Availability'

    row = table.rows[10]
    row.cells[0].text = "HLD"
    row.cells[1].text = 'High Level Design'

    row = table.rows[11]
    row.cells[0].text = "LLD"
    row.cells[1].text = 'Low Level Design'

    row = table.rows[12]
    row.cells[0].text = "IDM"
    row.cells[1].text = 'Infrastructure Data Management'

    row = table.rows[13]
    row.cells[0].text = "RPM"
    row.cells[1].text = 'RedHat Package Manager'

    row = table.rows[14]
    row.cells[0].text = "SLA"
    row.cells[1].text = 'Service Level Agreement'

    row = table.rows[15]
    row.cells[0].text = "SMB"
    row.cells[1].text = 'Server Message Block'

    row = table.rows[16]
    row.cells[0].text = "SAN"
    row.cells[1].text = 'Storage Area Network'

    row = table.rows[17]
    row.cells[0].text = "SSL"
    row.cells[1].text = 'Secure Sockets Layer'

    row = table.rows[18]
    row.cells[0].text = "RAID"
    row.cells[1].text = 'Redundant Array of Independent Disks'

    row = table.rows[19]
    row.cells[0].text = "UEFI"
    row.cells[1].text = 'Unified Extensible Firmware Interface'

    row = table.rows[20]
    row.cells[0].text = "EFI"
    row.cells[1].text = 'Extensible Firmware Interface'

    row = table.rows[21]
    row.cells[0].text = "GRUB"
    row.cells[1].text = 'GRand Unified Bootloader'

    row = table.rows[22]
    row.cells[0].text = "NTP"
    row.cells[1].text = 'Network Time Protocol'

    row = table.rows[23]
    row.cells[0].text = "LVM"
    row.cells[1].text = 'Logical Volume Manager'

    row = table.rows[24]
    row.cells[0].text = "SMTP"
    row.cells[1].text = 'Simple Mail Transfer Protocol'

    row = table.rows[25]
    row.cells[0].text = "TCP"
    row.cells[1].text = 'Transmission Control Protocol'

    row = table.rows[26]
    row.cells[0].text = "UDP"
    row.cells[1].text = 'User Datagram Protocol'

    row = table.rows[27]
    row.cells[0].text = "SNMP"
    row.cells[1].text = 'Simple Network Management'

    row = table.rows[28]
    row.cells[0].text = "FCoE"
    row.cells[1].text = 'Fiber channel over Ethernet'

    row = table.rows[29]
    row.cells[0].text = "HBA"
    row.cells[1].text = 'Host Bus adaptor'

    row = table.rows[30]
    row.cells[0].text = "YUM"
    row.cells[1].text = 'Yellow Dog Updater, Modified'

    row = table.rows[31]
    row.cells[0].text = "VLAN"
    row.cells[1].text = 'Virtual Local Area Network'

    row = table.rows[32]
    row.cells[0].text = "VM"
    row.cells[1].text = 'Virtual Machine'

    row = table.rows[33]
    row.cells[0].text = "WAN"
    row.cells[1].text = 'Wide Area Network'

    row = table.rows[34]
    row.cells[0].text = "CMO"
    row.cells[1].text = 'Current Mode of Operation'

    row = table.rows[35]
    row.cells[0].text = "FMO"
    row.cells[1].text = 'Future Mode of Operation'
    
    row = table.rows[36]
    row.cells[0].text = "SLES"
    row.cells[1].text = 'SUSE Linux Enterprise Server'

    row = table.rows[37]
    row.cells[0].text = "SLES"
    row.cells[1].text = 'SuSE Linux Enterprise Server'

    row = table.rows[38]
    row.cells[0].text = "OL"
    row.cells[1].text = 'Oracle Linux'

    # add a page break to start a new page
    doc.add_page_break()
    
    ## Server information 

    doc.add_heading(' Building Blocks ')
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The below table brings up all the basic information about the platforms that sits below the SLES layer.")
    doc_para = doc.add_paragraph()
    OS=""+str(platform.system())
    info = list(platform.uname())
    #patch = os.popen("cat /etc/SuSE-release|grep -w PATCHLEVEL|awk '{print $3}'").read()
    #patch = subprocess.check_output('grep "^PATCHLEVEL" /etc/SuSE-release |awk \'{print $3}\'',shell=True)
    ipaddr = socket.gethostname()
    serial = subprocess.check_output("prtdiag -v | awk '/Chassis Serial/{getline; getline; print}'",shell=True)
    hw = subprocess.check_output("prtdiag|grep 'System Configuration'|awk -F: '{print $2}'",shell=True)
    kernel = subprocess.check_output("pkg info kernel|grep Version|awk -F: '{print $2}'",shell=True)
    uname=platform.uname()
    uptime=subprocess.check_output("uptime |awk -F, '{print $2}'", shell=True)
    # uptime
    # ---------------
    #with open("uptime","r") as f:
    #    uptime=f.read().split(" ")[0].strip()
    #uptime=int(float(uptime))
    #uptime_hours=uptime//3600
    #uptime_minutes=(uptime % 3600) //60

    ## Table
    table = doc.add_table(rows=11, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True
    # populate header row --------
    heading_cells = table.rows[0].cells   
    heading_cells[0].paragraphs[0].add_run('Server ID').bold = True
    shade_cells([heading_cells[0]],"#0000FF")
    heading_cells[1].paragraphs[0].add_run('Server Details').bold = True
    shade_cells([heading_cells[1]],"#0000FF")

	
    row = table.rows[1]
    row.cells[0].text = "OS Platform"
    row.cells[1].text = (OS)
	
    row = table.rows[2]
    row.cells[0].text = "System"
    row.cells[1].text = (""+str(platform.node()))

    row = table.rows[3]
    row.cells[0].text = "IP Address"
    row.cells[1].text =(""+str(socket.gethostbyname(ipaddr)))

    row = table.rows[4]
    row.cells[0].text = "OS"
    row.cells[1].text = (""+str(platform.linux_distribution()))
	
    row = table.rows[5]
    row.cells[0].text = "PATCHLEVEL"
    row.cells[1].text = ""+ patch.decode().replace('\n','') +""

    row = table.rows[6]
    row.cells[0].text = "Serial Number"
    row.cells[1].text = ""+ serial.decode().replace('\n','') +""

    row = table.rows[7]
    row.cells[0].text = "Hardware Type"
    row.cells[1].text = ""+ hw.decode().replace('\n','') +""

    row = table.rows[8]
    row.cells[0].text = "Kernel Version"
    row.cells[1].text = ""+ kernel.decode().replace('\n','') +""

    row = table.rows[9] 
    row.cells[0].text = "Process"
    row.cells[1].text = (""+str(platform.processor()))

    row = table.rows[10]
    row.cells[0].text = "UPTIME"
    row.cells[1].text = (""+str(uptime))

    doc.add_heading(' Installed Software', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about List of Installed Software in the system")
    doc_para.add_run("\n ")
    package=os.popen("pkg list|grep -v IFO|awk '{print $1,$2,$3}'").read().splitlines()
    #package=os.popen("yum list installed|grep -Ev 'Modular|Subscription|Loaded|entitlement|Installed'|awk '{print $1,$2}'").read().splitlines()

    def convert_los_to_lol(input_list, seprator):
        for idx, row in enumerate(input_list):
            input_list[idx] = row.split(seprator)


    def get_row_column_from_lol(input_list):
        return len(input_list), len(input_list[0])


    def fill_table(Input_list, Input_table):
        for idxi, rows in enumerate(Input_list):
            if idxi == 0:
                continue
            table_row = Input_table.rows[idxi]
            for idxj, cell in enumerate(rows):
                table_row.cells[idxj].text = cell

    convert_los_to_lol(package, ' ')
    # Creating Table
    row, col = get_row_column_from_lol(package)
    package_table = doc.add_table(row, col)

    package_table.style = "Table Grid"
    package_table.allow_autofit = True

    #####Customizing Header Section for the packag_table####
    hdr_cells = package_table.rows[0].cells

    #hdr_cells[0].text = "Packages"
    hdr_cells[0].paragraphs[0].add_run('Packages').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Version').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('IFO').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    #hdr_cells[1].paragraphs[0].add_run(' Version').bold = True
    #shade_cells([hdr_cells[1]], "#0000FF")

    ###Fill rest of the package_table with values###
    fill_table(package, package_table)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()
    doc.add_heading(' Running Services', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about List of running Services in the system")
    doc_para.add_run("\n")
    services=os.popen("svcs -a|grep -v FMRI|awk '{print $1,$2,$3}'").read().splitlines()

    def convert_los_to_lol(input_list, seprator):
        for idx, row in enumerate(input_list):
            input_list[idx] = row.split(seprator)


    def get_row_column_from_lol(input_list):
        return len(input_list), len(input_list[0])


    def fill_table(Input_list, Input_table):
        for idxi, rows in enumerate(Input_list):
            if idxi == 0:
                continue
            table_row = Input_table.rows[idxi]
            for idxj, cell in enumerate(rows):
                table_row.cells[idxj].text = cell

    convert_los_to_lol(services, ' ')

    	# Creating Table
    row, col = get_row_column_from_lol(services)
    services_table = doc.add_table(row, col)
	
    services_table.style = "Table Grid"
    services_table.allow_autofit = True

    #####Customizing Header Section for the services_table####
    hdr_cells = services_table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('STATE').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('STIME').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('FMRI').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")

    ###Fill rest of the services_table with values###
    fill_table(services, services_table)

    doc.add_page_break()
	
    doc.add_heading(' OS Patches ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("Below are the list of Security Patches implemented at O/S level. It is recommended to update the hotfixes as soon as it is released ")
    doc_para = doc.add_paragraph()

    patch = os.popen("grep -h PATCH_INFO_ /var/sadm/pkg/SUNW*/pkginfo | sed -e 's/From:.*//' |grep 2019 |head").read()
    with open ("patch.txt","w") as wh:
        wh.write(patch)
    wh.close()
    p1 = os.popen("cat patch.txt|awk -F: '{print $1,$2}'").read().splitline()
    ## Create tables
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True

    #####Customizing Header Section for the patches_table####
    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Patch Details').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Installed Date').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")

    ###Fill rest  f the patches_table with values###
    for item in p1:
        patches2 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = patches2[0]
        row_cells[2].text = patches2[5]

    doc.add_heading(' Local User Account ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about Local User Account in the system. ")
    doc_para = doc.add_paragraph()
    users=os.popen("cat /etc/passwd|grep '^root'|awk -F: '{print $1,$3,$4,$6,$7}';awk -F: '$3 >=1000 {print $1,$3,$4,$6,$7}' /etc/passwd|grep -v nobody").read().splitlines()

    	## Create tables
    table = doc.add_table(rows=1, cols=5)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('UserName').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('UID').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('GID').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('HomeDirectory').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('DefaultShell').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")

    for item in users:
        user = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = user[0]
        row_cells[1].text = user[1]
        row_cells[2].text = user[2]
        row_cells[3].text = user[3]
        row_cells[4].text = user[4]

    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()

    doc.add_heading(' Running Processes', 2 )
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about List of running processes in the system. ")
    doc_para.add_run("\n")
    process=os.popen("/usr/bin/ps -eo user,pid,comm|awk '{print $1,$2,$3}'").read().splitlines()

    def convert_los_to_lol(input_list, seprator):
        for idx, row in enumerate(input_list):
            input_list[idx] = row.split(seprator)

    def get_row_column_from_lol(input_list):
        return len(input_list), len(input_list[0])


    def fill_table(Input_list, Input_table):
        for idxi, rows in enumerate(Input_list):
            if idxi == 0:
                continue
            table_row = Input_table.rows[idxi]
            for idxj, cell in enumerate(rows):
                table_row.cells[idxj].text = cell


    convert_los_to_lol(process, ' ')


    # Creating Table
    row, col = get_row_column_from_lol(process)
    process_table = doc.add_table(row, col)

    process_table.style = "Table Grid"
    process_table.allow_autofit = True

    hdr_cells = process_table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('USER').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('PID').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('COMMAND').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")


    	###Fill rest of the process_table with values###
    fill_table(process, process_table)

    doc.add_page_break()

    doc.add_heading(' Hardware Orchestration')
    doc_para = doc.add_paragraph("This section brings about the behaviour of hardware during the run to have an overview of the operations as a whole. ")
    doc.add_heading(' Processors ', 2)
    doc_para = doc.add_paragraph()
    v_phy=(""+str(psutil.cpu_count(logical=False)))
    v_core=(""+str(psutil.cpu_count(logical=True)))

    def cpuinfo():
        cpuinfo=OrderedDict()
        procinfo=OrderedDict()
        nprocs = 0
        with open('/proc/cpuinfo') as f:
            for line in f:
                if not line.strip():
                    cpuinfo['proc%s' % nprocs] = procinfo
                    nprocs=nprocs+1
                    procinfo=OrderedDict()
                else:
                    if len(line.split(':')) == 2:
                        procinfo[line.split(':')[0].strip()] = line.split(':')[1].strip()
                    else:
                        procinfo[line.split(':')[0].strip()] = ''
        return cpuinfo

        if __name__=='__main__':
            cpuinfo = cpuinfo()
            for processor in cpuinfo.keys():
                cpumodel=(""+str(cpuinfo[processor]['model name']))
            	#cpumodel=(" {cpuinfo[processor]['model name']}")
    ## Table ###

    table = doc.add_table(rows=4, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True
    	# populate header row --------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('CPU').bold = True
    shade_cells([heading_cells[0]], "#0000FF")
    heading_cells[1].paragraphs[0].add_run('CPU Information').bold = True
    shade_cells([heading_cells[1]], "#0000FF")

    row = table.rows[1]
    row.cells[0].text = "CPU Model"
    row.cells[1].text = cpumodel

    row = table.rows[2]
    row.cells[0].text = "Physical cores"
    row.cells[1].text = v_phy

    row = table.rows[3]
    row.cells[0].text = "Total cores"
    row.cells[1].text = v_core
	
    doc_para.add_run("\n")


    doc.add_heading(' Storage ', 2)
    doc_para = doc.add_paragraph()
    fs=os.popen("df -Ph|egrep -v 'devices|dev|ctfs|proc|mnttab|objfs|sharefs|fd|Filesystem'").read()
    with open("DISK_INFO.txt","w") as wh:
        wh.write(fs)
    wh.close()
    disk=os.popen("cat DISK_INFO.txt").read().splitlines()

    table = doc.add_table(rows=1, cols=7)
    table.style = "Table Grid"
    table.allow_autofit = True
	
    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Filesystem').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Size').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('Used').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('Avail').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('Use%').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")
    hdr_cells[5].paragraphs[0].add_run('Mounted on').bold = True
    shade_cells([hdr_cells[5]], "#0000FF")

    for item in disk:
        fs2 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = fs2[0]
        row_cells[1].text = fs2[1]
        row_cells[2].text = fs2[2]
        row_cells[3].text = fs2[3]
        row_cells[4].text = fs2[4]
        row_cells[5].text = fs2[5]
		
    doc.add_heading(' Memory ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The following table shows the current status of memory utilization by Linux system and provides useful analytical information about memory")
    doc_para.add_run("\n ")
    svmem=psutil.virtual_memory()

    ### Table ###
    table = doc.add_table(rows=5, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True
    	# populate header row --------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('Memory').bold = True
    shade_cells([heading_cells[0]],"#0000FF")
    heading_cells[1].paragraphs[0].add_run('Memory Information').bold = True
    shade_cells([heading_cells[1]],"#0000FF")

    row = table.rows[1]
    row.cells[0].text = "Total Memory"
    row.cells[1].text = (""+str(get_size(svmem.total)))

    row = table.rows[2]
    row.cells[0].text = "Available Memory"
    row.cells[1].text = (""+str(get_size(svmem.available)))
	
    row = table.rows[3]
    row.cells[0].text = "Used Memory"
    row.cells[1].text = (""+str(get_size(svmem.used)))

    row = table.rows[4]
    row.cells[0].text = "Percentage"
    row.cells[1].text = (""+str(svmem.percent))
	
    doc_para = doc.add_paragraph()

    doc.add_heading(' SWAP Memory ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The following table shows the current status of virtual memory utilization by Linux system and provides useful analytical information about memory")
    doc_para = doc.add_paragraph()
    swap=psutil.swap_memory()

    	### Table ####
    table = doc.add_table(rows=5, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True
    # populate header row --------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('SWAP').bold = True
    shade_cells([heading_cells[0]],"#0000FF")
    heading_cells[1].paragraphs[0].add_run('Swap Memory Information').bold = True
    shade_cells([heading_cells[1]],"#0000FF")

    row = table.rows[1]
    row.cells[0].text = "Total Memory"
    row.cells[1].text = (""+str(get_size(swap.total)))
    #row.cells[1].text = ("{get_size(swap.total)}")

    row = table.rows[2]
    row.cells[0].text = "Available Memory"
    row.cells[1].text = (""+str(get_size(swap.free)))
    #row.cells[1].text = ("{get_size(swap.free)}")

    row = table.rows[3]
    row.cells[0].text = "Used Memory"
    row.cells[1].text = (""+str(get_size(swap.used)))
    #row.cells[1].text = ("{get_size(swap.used)}")

    row = table.rows[4]
    row.cells[0].text = "Percentage"
    row.cells[1].text = (""+str(swap.percent))
    #row.cells[1].text = ("{swap.percent}%")

    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()

    doc.add_heading(' Network ', 2)
    doc_para = doc.add_paragraph()

    nw=os.popen("ipadm show-addr|egrep -v 'v6|ADDROBJ'").read()
    with open("NETWORK.txt","w") as wh:
        wh.write(nw)
    wh.close()
    nw1=os.popen("cat NETWORK.txt").read().splitlines()
	
    table = doc.add_table(rows=1, cols=3)
    table.style = "Table Grid"
    table.allow_autofit = True
	
    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Interface Device').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Class/Type').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('State').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('IP Address').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
	
    for item in nw1:
        nw2 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = nw2[0]
        row_cells[1].text = nw2[1]
        row_cells[2].text = nw2[2]
        row_cells[3].text = nw2[3]
        row_cells[4].text = nw2[4]

    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()
    
    doc.add_heading(' Network Route', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about Route in the system. ")
    doc_para.add_run("\n ")
    networkr=os.popen("netstat -rn|egrep -v 'Gateway|::1|127.0.0.1|IPv6|fe80|---|IPv4'").read().splitlines()

    	## Create tables
    table = doc.add_table(rows=1, cols=8)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Destination').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Gateway').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('Flags').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('Flags').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('Use').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")
    hdr_cells[5].paragraphs[0].add_run('Interface').bold = True
    shade_cells([hdr_cells[5]], "#0000FF")

    for item in networkr:
        route = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = route[0]
        row_cells[1].text = route[1]
        row_cells[2].text = route[2]
        row_cells[3].text = route[3]
        row_cells[4].text = route[4]
        row_cells[5].text = route[5]

    doc.add_page_break()

    doc.add_heading(' SOLARIS')
    doc.add_heading(' Current Login Details', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section contains the Current login information in SLES server ")
    doc_para.add_run("\n ")
    login=os.popen("/usr/bin/who|grep -v console|awk '{print $1,$2,$3':'$4,$5,$6").read().splitlines()

    table = doc.add_table(rows=1, cols=5)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Login').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Terminal').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('Login-Date').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('Login-Time').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('Remote-Server').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")
    hdr_cells[5].paragraphs[0].add_run('Remote-Server').bold = True
    shade_cells([hdr_cells[5]], "#0000FF")

    for item in login:
        loginc = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = loginc[0]
        row_cells[1].text = loginc[1]
        row_cells[2].text = loginc[2]
        row_cells[3].text = loginc[3]
        row_cells[4].text = loginc[4]
        row_cells[5].text = loginc[5]


    doc.add_heading(' Firewall', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The system should be configured to use Firewalld to allow and deny access.")
    doc_para.add_run("\n ")
    	#firewalls=os.popen("firewall-cmd --state|grep -v '^$'").read().splitlines()
    firewalls=os.popen("systemctl is-active SuSEfirewall2.service").read().splitlines()

    	## Create tables
    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True

    for line in firewalls:
        fw=line.strip()
        row_cells = table.add_row().cells
        row_cells[0].paragraphs[0].add_run('Firewall status').bold = True
        row_cells[1].text = fw

    doc_para = doc.add_paragraph()

    fd=os.popen("iptables -L").read()
    table = doc.add_table(rows=2, cols=1)
    table.style = "Table Grid"
    table.allow_autofit = True
    	# populate header row --------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('Firewall Configuration:').bold = True
    shade_cells([heading_cells[0]], "#0000FF")
    row = table.rows[1]
    row.cells[0].text = (fd)
    doc_para = doc.add_paragraph()
    	#doc_para = doc.add_paragraph("Here services can be enabled to allow incoming connections. The above shows the default of primary interface firewalled and only port 22 open.")

    doc.add_page_break()
	
    doc.add_heading('Solaris Zone ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The default run level should be set to be multi-user.target")
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n ")
    zn=os.popen("zoneadm list -vc").read().splitline()
    table = doc.add_table(rows=2, cols=6)
    table.style = "Table Grid"
    table.allow_autofit = True
    	# populate header row -------
    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('ID').bold = True
    shade_cells([heading_cells[0]],"#0000FF")
    hdr_cells[1].paragraphs[0].add_run('NAME').bold = True
    shade_cells([heading_cells[1]],"#0000FF")
    hdr_cells[2].paragraphs[0].add_run('STATUS').bold = True
    shade_cells([heading_cells[2]],"#0000FF")
    hdr_cells[3].paragraphs[0].add_run('PATH').bold = True
    shade_cells([heading_cells[3]],"#0000FF")
    hdr_cells[4].paragraphs[0].add_run('BRAND').bold = True
    shade_cells([heading_cells[4]],"#0000FF")
    hdr_cells[5].paragraphs[0].add_run('IP').bold = True
    shade_cells([heading_cells[5]],"#0000FF")
    for item in zn:
        zn1 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = zn1[0]
        row_cells[1].text = zn1[1]
        row_cells[2].text = zn1[2]
        row_cells[3].text = zn1[3]
        row_cells[4].text = zn1[4]
        row_cells[5].text = zn1[5]

    #doc.add_page_break()

    doc.add_heading(' Chrony/NTP', 2)
    doc_para = doc.add_paragraph("NTP is an implementation of the Network Time Protocol.")
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("The output displays information about the current time sources that ntpq is accessing.")
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n ")
    ntp=os.popen("ntpq -p|grep -Ev 'remote|==='").read().splitlines()
    table = doc.add_table(rows=1, cols=10)
    table.style = "Table Grid"
    table.allow_autofit = True
	
    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('remote').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('refid').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('st').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('t').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('when').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")
    hdr_cells[5].paragraphs[0].add_run('poll').bold = True
    shade_cells([hdr_cells[5]], "#0000FF")
    hdr_cells[6].paragraphs[0].add_run('reach').bold = True
    shade_cells([hdr_cells[6]], "#0000FF")
    hdr_cells[7].paragraphs[0].add_run('delay').bold = True
    shade_cells([hdr_cells[7]], "#0000FF")
    hdr_cells[8].paragraphs[0].add_run('offset').bold = True
    shade_cells([hdr_cells[8]], "#0000FF")
    hdr_cells[9].paragraphs[0].add_run('jitter').bold = True
    shade_cells([hdr_cells[9]], "#0000FF")
	

    for item in ntp:
        ntp1 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text =  ntp1[0]
        row_cells[1].text =  ntp1[1]
        row_cells[2].text =  ntp1[2]
        row_cells[3].text =  ntp1[3]
        row_cells[4].text =  ntp1[4]
        row_cells[5].text =  ntp1[5]
        row_cells[6].text =  ntp1[6]
        row_cells[7].text =  ntp1[7]
        row_cells[8].text =  ntp1[8]
        row_cells[9].text =  ntp1[9]

    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()

    doc.add_heading(' TimeZone', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("This section provides information about current TimeZone in the system. ")
    doc_para.add_run("\n ")
	
    tz=os.popen("nlsadm get-timezone").read().splitlines()

    table = doc.add_table(rows=0, cols=2)
    table.style = "Table Grid"
    table.allow_autofit = True

    for item in tz:
        tz1 = item.split("=")
        row_cells = table.add_row().cells
        row_cells[0].paragraphs[0].add_run('Time zone').bold = True
        row_cells[1].text = tz1[1]

    doc.add_page_break()
    
    doc.add_heading(' Cluster ', 2)
    doc_para = doc.add_paragraph()
    
    doc.add_heading(' Log File ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("Log files are files that contain messages about the system, including the kernel, services, and applications running on it. There are different log files for different information. For example:")
    doc_para = doc.add_paragraph("/var/adm/messages: This file has all the global system messages located inside, including the messages that are logged during system startup. Depending on how the syslog config file is sent up, there are several things that are logged in this file including mail, cron, daemon, kern, auth, etc.", style='List Bullet')
    doc_para = doc.add_paragraph()
    
    file = pathlib.Path("/var/adm/messages")
    if file.exists ():
        m=os.popen('ls -lh /var/adm/messages|awk \'{print $9 ";" $6,$7,$8 ";" $5 ";" echo "Live Log File"}\'').read()
    else:
        m="/var/adm/messages;File not exist; ; \n"
    file = pathlib.Path("/var/log/messages-*")
    if file.exists ():
        m1=os.popen('ls -lh /var/log/messages.*|awk \'{print $9 ";" $6,$7,$8 ";" $5 ";" echo "Archive Log File"}\'').read()
    else:
        m1="/var/log/messages-;Archive File not exist ; ; \n"
    with open("LOG.txt","w") as wh:
        wh.write(m+m1)
    wh.close()
	
    log=os.popen("cat LOG.txt").read().splitlines()

    ## Create tables
    table = doc.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Log_File').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Date').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('Size').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('File Type').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")

    for item in log:
        log1 = item.split(";")
        row_cells = table.add_row().cells
        row_cells[0].text = log1[0]
        row_cells[1].text = log1[1]
        row_cells[2].text = log1[2]
        row_cells[3].text = log1[3]

    doc.add_heading(' Atos Technology Framework ')
    doc_para = doc.add_paragraph("The Atos Technology Framework provides a tooling solution for the Atos Service Management Model (ASMM) and the associated processes and consistently manages the interactions between all components, the Services and all users based on a flexible IT architecture. Henkel tooling will be removed, and Atos tooling will be installed.")
    doc.add_heading(' Monitoring Tool ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph()
    ase = os.popen("pkginfo ase|awk '{print $2}'").read()
    if len(nacl) != 0:
        nacl_service=os.popen("su - nagios -c 'NaCl/NaCl -s 10.194.33.216'|grep -v Oracle").read()
        nacl=os.popen("su - nagios -c 'NaCl/NaCl -V'|grep NaCl|awk -F- '{print $1}'").read()
        ase = os.popen("pkginfo -l ase|egrep 'PKGINST|VERSION'").read()
        ase_service=os.popen("ps aux |grep ase|grep -v grep|awk '{print $1,$2,$8,$11}'").read()
        table = doc.add_table(rows=2, cols=4)
        table.style = "Table Grid"
        table.allow_autofit = True
        	# populate header row -------
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('CMF Nagios Agent').bold = True
        shade_cells([heading_cells[0]],"#0000FF")
        heading_cells[1].paragraphs[0].add_run('CMF Nagios Agent Status').bold = True
        shade_cells([heading_cells[1]],"#0000FF")
        heading_cells[2].paragraphs[0].add_run('ASE Agent').bold = True
        shade_cells([heading_cells[2]],"#0000FF") 
        heading_cells[3].paragraphs[0].add_run('ASE Agent Status').bold = True
        shade_cells([heading_cells[3]],"#0000FF")
        row = table.rows[1]
        row.cells[0].text = nacl
        row.cells[1].text = nacl_service
        row.cells[2].text = ase
        row.cells[3].text = ase_service
    else:
        doc_para.add_run("atos-cmf-client-nacl package is not installed").bold = True

    doc.add_heading(' Patching Tool ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("Linux servers will be patched using BMC blade logic tool. BMC BladeLogic agent RPM will be installed in the server and GDTS BladeLogic team will add that server into the management. RPM should be received from GDTS team")
    doc_para.add_run("\n")
    bloadelogic=os.popen("pkginfo BLOGrscd|awk '{print $2}'")
    #bladelogic=os.popen("/opt/bmc/bladelogic/RSCD/sbin/version|grep -v Copyright").read()
    if len(bladelogic) != 0:
        bladelogic=os.popen("pkginfo -l BLOGrscd|egrep 'PKGINST|VERSION'").read()
        table = doc.add_table(rows=2, cols=1)
        table.style = "Table Grid"
        table.allow_autofit = True
        # populate header row -------
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('BMC Agent').bold = True
        shade_cells([heading_cells[0]],"#0000FF")
        row = table.rows[1]
        row.cells[0].text = (bladelogic)
        doc_para = doc.add_paragraph()
        doc_para.add_run("\n ")
        doc_para.add_run("BMC Agent Status").bold = True
        doc_para.add_run("\n")
        bladelogic1=os.popen("ps aux|grep rscd |grep -v grep|awk '{print $1,$2,$7,$10}'").read().splitlines()

        ## Create tables
        table = doc.add_table(rows=1, cols=4)
        table.style = "Table Grid"
        table.allow_autofit = True
    
        hdr_cells = table.rows[0].cells
        hdr_cells[0].paragraphs[0].add_run('USER').bold = True
        shade_cells([hdr_cells[0]], "#0000FF")
        hdr_cells[1].paragraphs[0].add_run('PID').bold = True
        shade_cells([hdr_cells[1]], "#0000FF")
        hdr_cells[2].paragraphs[0].add_run('STAT').bold = True
        shade_cells([hdr_cells[2]], "#0000FF")
        hdr_cells[3].paragraphs[0].add_run('Service').bold = True
        shade_cells([hdr_cells[3]], "#0000FF")

        for item in bladelogic1:
            bl = item.split()
            row_cells = table.add_row().cells
            row_cells[0].text = bl[0]
            row_cells[1].text = bl[1]
            row_cells[2].text = bl[2]
            row_cells[3].text = bl[3]
    else:
        doc_para.add_run("BladeLogic package is not installed").bold = True

    doc.add_heading(' Backup Tool ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("EMC Networker agent will be installed on Linux servers")
    doc_para.add_run("\n")
    networker=os.popen("pkginfo|grep -i networker|awk '{print $2}'").read()
    if len(networker) != 0:
        networkera=os.open("pkginfo -l LGTOclnt|egrep 'PKGINST|VERSION'").read()
        nwservice=os.popen("systemctl is-active networker|awk'{print $1,$2,$7,$10}'").read()
        table = doc.add_table(rows=2, cols=2)
        table.style = "Table Grid"
        table.allow_autofit = True
        # populate header row -------
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('NetWorker Client').bold = True
        shade_cells([heading_cells[0]],"#0000FF")
        heading_cells[1].paragraphs[0].add_run('NetWorker Service').bold = True
        shade_cells([heading_cells[1]],"#0000FF")
        row = table.rows[1]
        row.cells[0].text = (networker)
        row.cells[1].text = (nwservice)
    else:
        doc_para.add_run("Networker Agent is not installed").bold = True

    doc.add_heading(' System Recovery Tool ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("Relax-and-Recover(ReaR) is a recovery and system migration utility. The utility produces a bootable image and restores from backup using this image. It also allows to restore to different hardware and can therefore be used as a migration utility as well.")
    doc_para.add_run("\n")
    rear = os.popen("rpm -qa rear").read()
    if len(rear) != 0:
        rear=os.popen("/usr/sbin/rear -V").read()
        table = doc.add_table(rows=2, cols=1)
        table.style = "Table Grid"
        table.allow_autofit = True
        # populate header row -------
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('REAR Version').bold = True
        shade_cells([heading_cells[0]],"#0000FF")
        row = table.rows[1]
        row.cells[0].text = (rear)
    else:
        doc_para.add_run("rear Package is not installed").bold = True

    doc.add_page_break()

    print("Perform Health Checkup Section")
    doc.add_heading(' Health Checkup ')
    doc_para = doc.add_paragraph("The following data table is very important during hardening and onboarding of SLES Server instance. It provides Precise information about server health based on Information Security Standards. ")
    doc_para.add_run("\n ")
    os.system("/usr/bin/python Linux_Helath_Check.py")
    ht=os.popen("cat HEALTH.txt").read().splitlines()

    ## Create tables
    table = doc.add_table(rows=1, cols=3)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells	
    hdr_cells[0].paragraphs[0].add_run('NAME').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('THRESHOLD(%)').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('STATUS').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")

    for item in ht:
        Green = parse_xml(r'<w:shd {} w:fill="00FF00"/>'.format(nsdecls('w')))
        Red = parse_xml(r'<w:shd {} w:fill="FF0000"/>'.format(nsdecls('w')))
        Orange = parse_xml(r'<w:shd {} w:fill="FFA500"/>'.format(nsdecls('w')))

        ht1 = item.split()
        row_cells = table.add_row().cells
        row_cells[0].text = ht1[0]
        row_cells[1].text = ht1[1]
        if ht1[2] == 'OK':
            row_cells[2].paragraphs[0].add_run(ht1[2]).bold = True
            row_cells[2]._tc.get_or_add_tcPr().append(Green)
        elif ht1[2] == 'WARNING':
            row_cells[2].paragraphs[0].add_run(ht1[2]).bold = True
            row_cells[2]._tc.get_or_add_tcPr().append(Orange)
        else:
            row_cells[2].paragraphs[0].add_run(ht1[2]).bold = True
            row_cells[2]._tc.get_or_add_tcPr().append(Red)

    doc.add_page_break()

    print("Perform TSS Section")
    doc.add_heading(' Atos TSS ')
    doc_para = doc.add_paragraph("Atos standard build procedure will be used to harden the system. Every new server installed should be secured following the Unix Security Standards.  Note that there may be customer requirements which mean that configurations listed in the policy may need to be altered.  Any such alterations should be documented as exceptions to the Unix Security Standards in the server documentation.")
    doc_para.add_run("\n ")
    os.system("/usr/bin/python tss-script-new.py")
    tss1=os.popen("cat TSS.txt").read().splitlines()

    	## Create tables
    table = doc.add_table(rows=1, cols=5)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Measure ID').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Measure Title').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('TSS Recommendation').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('Current Value').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")
    hdr_cells[4].paragraphs[0].add_run('Compliance/Non-Compliance').bold = True
    shade_cells([hdr_cells[4]], "#0000FF")

    for item in tss1:
        Green = parse_xml(r'<w:shd {} w:fill="00FF00"/>'.format(nsdecls('w')))
        Red = parse_xml(r'<w:shd {} w:fill="FF0000"/>'.format(nsdecls('w')))
        Orange = parse_xml(r'<w:shd {} w:fill="FFA500"/>'.format(nsdecls('w')))
        tss2 = item.split(":")
        row_cells = table.add_row().cells
        row_cells[0].text = tss2[0]
        row_cells[1].text = tss2[1]
        row_cells[2].text = tss2[2]
        row_cells[3].text = tss2[3]
        if tss2[4] == 'Compliance':
            row_cells[4].paragraphs[0].add_run(tss2[4]).bold = True
            row_cells[4]._tc.get_or_add_tcPr().append(Green)
        else:
            row_cells[4].paragraphs[0].add_run(tss2[4]).bold = True
            row_cells[4]._tc.get_or_add_tcPr().append(Red)

    doc.add_page_break()

    print("Perform Risk Analysis Section")
    doc.add_heading(' Risk Analysis ')
    doc_para = doc.add_paragraph("The following data table is very important during hardening and onboarding of SLES Servers. It provides Deep Dive Risk information that must be taken into consideration . ")
    doc_para.add_run("\n ")
    os.system("/usr/bin/python risk-ana-script-new.py")
    riska=os.popen("cat RISK_ANA.txt").read().splitlines()

    	## Create tables
    table = doc.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    table.allow_autofit = True

    hdr_cells = table.rows[0].cells
    hdr_cells[0].paragraphs[0].add_run('Risk Measure').bold = True
    shade_cells([hdr_cells[0]], "#0000FF")
    hdr_cells[1].paragraphs[0].add_run('Risk Assessment').bold = True
    shade_cells([hdr_cells[1]], "#0000FF")
    hdr_cells[2].paragraphs[0].add_run('Assessment Result').bold = True
    shade_cells([hdr_cells[2]], "#0000FF")
    hdr_cells[3].paragraphs[0].add_run('Risk Severity').bold = True
    shade_cells([hdr_cells[3]], "#0000FF")

    for item in riska:
        Green = parse_xml(r'<w:shd {} w:fill="00FF00"/>'.format(nsdecls('w')))
        Red = parse_xml(r'<w:shd {} w:fill="FF0000"/>'.format(nsdecls('w')))
        Orange = parse_xml(r'<w:shd {} w:fill="FFA500"/>'.format(nsdecls('w')))
        rka = item.split(":")
        row_cells = table.add_row().cells
        row_cells[0].text = rka[0]
        row_cells[1].text = rka[1]
        row_cells[2].text = rka[2]
        if rka[3] == 'No-Risk':
            row_cells[3].paragraphs[0].add_run(rka[3]).bold = True
            row_cells[3]._tc.get_or_add_tcPr().append(Green)
        elif rka[3] == 'MID-Risk':
            row_cells[3].paragraphs[0].add_run(rka[3]).bold = True
            row_cells[3]._tc.get_or_add_tcPr().append(Orange)
        else:
            row_cells[3].paragraphs[0].add_run(rka[3]).bold = True
            row_cells[3]._tc.get_or_add_tcPr().append(Red)

    doc.add_page_break()

    doc.add_heading(' Backup ')
    doc_para = doc.add_paragraph("EMC Networker agent will be installed on servers, under '/nsr' to take all drives/partition backup and it will be backed up in accordance with the existing Atos standard regime.")
    doc_para = doc.add_paragraph("RMAN backup tool will be used to take Oracle DB backups.", style='List Bullet')
    doc_para = doc.add_paragraph("A full backup will be done once a week, incremental backups will be done for the rest of the week. Backup retention period will be one month or as per Atos backup policy standard.", style='List Bullet')
    doc_para.add_run("\n ")
    mount=os.popen("df -h|grep -v 'File'|awk '{print $6}'|grep -Ev 'run|dev|sys|mnt'").read()
    vg=os.popen("vgs").read()
    if len(vg) != 0: 
        with open("vg.txt","w") as wh:
            wh.write(vg)
        wh.close()
        v = open("vg.txt","r")
        for line in v:
            fields = line.split()
            f1=fields[5]
            f2 = ""+str(f1)+""
            f3 = ""+str(f2.replace('<', ' ').replace('VSize',' '))+""
            v.close()
            table = doc.add_table(rows=3, cols=5)
            table.style = "Table Grid"
            table.allow_autofit = True
            # populate header row -------
            heading_cells = table.rows[0].cells
            heading_cells[0].paragraphs[0].add_run('Service Component').bold = True
            shade_cells([heading_cells[0]],"#0000FF")
            heading_cells[1].paragraphs[0].add_run('Devices').bold = True
            shade_cells([heading_cells[1]],"#0000FF")
            heading_cells[2].paragraphs[0].add_run('Data Volumes (GB)').bold = True
            shade_cells([heading_cells[2]],"#0000FF")
            heading_cells[3].paragraphs[0].add_run('Agent Type').bold = True
            shade_cells([heading_cells[3]],"#0000FF")
            heading_cells[4].paragraphs[0].add_run('Archive Frequency').bold = True
            shade_cells([heading_cells[4]],"#0000FF")
            row = table.rows[1]
            row.cells[0].text = "Operating system , all drives/partition Local"
            row.cells[1].text = (mount)
            row.cells[2].text = (f3)
            row.cells[3].text = "EMC Networker"
            row.cells[4].text = "Daily Incremental\Weekly Full"
            row = table.rows[2]
            row.cells[0].text = "Operating system , all drives/partition on SAN"
            row.cells[1].text = "Not Applicable"
            row.cells[2].text = "Not Applicable"
            row.cells[3].text = "EMC Networker"
            row.cells[4].text = "Daily Incremental\Weekly Full"
    else:
        disk=os.popen("fdisk -l|grep sd[a-z]|grep Disk|awk -F, '{print $1}'").read()
        table = doc.add_table(rows=3, cols=5)
        table.style = "Table Grid"
        table.allow_autofit = True
            # populate header row -------
        heading_cells = table.rows[0].cells
        heading_cells[0].paragraphs[0].add_run('Service Component').bold = True
        shade_cells([heading_cells[0]],"#0000FF")
        heading_cells[1].paragraphs[0].add_run('Devices').bold = True
        shade_cells([heading_cells[1]],"#0000FF")
        heading_cells[2].paragraphs[0].add_run('Data Volumes (GB)').bold = True
        shade_cells([heading_cells[2]],"#0000FF")
        heading_cells[3].paragraphs[0].add_run('Agent Type').bold = True
        shade_cells([heading_cells[3]],"#0000FF")
        heading_cells[4].paragraphs[0].add_run('Archive Frequency').bold = True
        shade_cells([heading_cells[4]],"#0000FF")
        row = table.rows[1]
        row.cells[0].text = "Operating system , all drives/partition Local"
        row.cells[1].text = (mount)
        row.cells[2].text = (disk)
        row.cells[3].text = "EMC Networker"
        row.cells[4].text = "Daily Incremental\Weekly Full"
        row = table.rows[2]
        row.cells[0].text = "Operating system , all drives/partition on SAN"
        row.cells[1].text = "Not Applicable"
        row.cells[2].text = "Not Applicable"
        row.cells[3].text = "EMC Networker"
        row.cells[4].text = "Daily Incremental\Weekly Full"

    doc.add_page_break()

    doc.add_heading(' System Recovery ')
    doc_para = doc.add_paragraph("System recovery processes are used to restore a server after some failure be it hardware or software, it can be regarded as part of Disaster Recovery (DR) or as a separate entity if a customer does not have DR. There are several methods of system recovery listed below:")
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n")
    doc_para.add_run("Relax and Recover (REAR)").bold = True
    doc_para.add_run("\n")
    doc_para.add_run("Relax-and-Recover produces a bootable image which can recreate the system's original storage layout. Once that is done it initiates a restore from backup. Since the storage layout can be modified prior to recovery, and dissimilar hardware and virtualization is supported, Relax-and-Recover offers the flexibility to be used for complex system migrations.")
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n")
    doc_para.add_run("Enterprise system restore (NetBackup / Networker etc) ").bold = True
    doc_para.add_run("\n")
    doc_para.add_run("An enterprise solution can be used to restore a system such as NetBackup (Symantec) or Networker (EMC).")

    doc.add_page_break()

    doc.add_heading(' SuSE Licensing ')
    doc_para = doc.add_paragraph("We have specialized buying programs to streamline software licensing. Use a SUSE buying program to purchase all your software licenses, maintenance, and receive volume discounts. Choose from the following options:")
    doc_para = doc.add_paragraph("Academic", style='List Bullet')
    doc_para = doc.add_paragraph("Business", style='List Bullet')
    doc_para = doc.add_paragraph("EULA", style='List Bullet')
    doc_para = doc.add_paragraph("Government", style='List Bullet')
    doc_para = doc.add_paragraph("Hosting", style='List Bullet')
    doc_para = doc.add_paragraph("Non-profit", style='List Bullet')
    doc_para = doc.add_paragraph()
    doc_para.add_run("\n")
    	
    doc.add_page_break()

    doc.add_heading(' SuSE LifeCycle ')
    doc.add_heading(' End of Life ', 2)
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph("SUSE products are supported for up to thirteen years. Verify key lifecycle dates for your product in the table below.")
    doc_para.add_run("\n")
    #doc_para.add_run("\n")
    p = doc.add_paragraph()
    add_hyperlink(p, 'SuSE Linux Enterprise Server Life Cycle', "https://www.suse.com/lifecycle/")
    doc_para.add_run("\n")
    doc_para = doc.add_paragraph()
    doc_para = doc.add_paragraph(" The content has been taken from offline")
    doc_para = doc.add_paragraph()
    table = doc.add_table(rows=7, cols=4)
    table.style = "Table Grid"
    table.allow_autofit = True
    # populate header row -------
    heading_cells = table.rows[0].cells
    heading_cells[0].paragraphs[0].add_run('Service Pack Release').bold = True
    shade_cells([heading_cells[0]],"#0000FF")
    heading_cells[1].paragraphs[0].add_run('FCS Date').bold = True
    shade_cells([heading_cells[1]],"#0000FF")
    heading_cells[2].paragraphs[0].add_run('General Ends').bold = True
    shade_cells([heading_cells[2]],"#0000FF")
    heading_cells[3].paragraphs[0].add_run('LTSS Ends').bold = True
    shade_cells([heading_cells[3]],"#0000FF")

    row = table.rows[1]
    row.cells[0].text = "SUSE Linux Enterprise Server 12"
    row.cells[1].text = "27 Oct 2014"
    row.cells[2].text = "30 June 2016"
    row.cells[3].text = "01 July 2019"

    row = table.rows[2]
    row.cells[0].text = "SUSE Linux Enterprise Server 12 SP1"
    row.cells[1].text = "15 Dec 2015"
    row.cells[2].text = "31 May 2017"
    row.cells[3].text = "31 May 2020"

    row = table.rows[3]
    row.cells[0].text = "SUSE Linux Enterprise Server 12 SP2"
    row.cells[1].text = "08 Nov 2016"
    row.cells[2].text = "31 Mar 2018"
    row.cells[3].text = "31 Mar 2021"

    row = table.rows[4]
    row.cells[0].text = "SUSE Linux Enterprise Server 12 SP3"
    row.cells[1].text = "07 Sep 2017"
    row.cells[2].text = "30 Jun 2019"
    row.cells[3].text = "30 Jun 2022"


    row = table.rows[5]
    row.cells[0].text = "SUSE Linux Enterprise Server 12 SP4"
    row.cells[1].text = "12 Dec 2018"
    row.cells[2].text = "30 Jun 2020"
    row.cells[3].text = "30 Jun 2023"


    row = table.rows[6]
    row.cells[0].text = "SUSE Linux Enterprise Server 12 SP5"
    row.cells[1].text = "12 Dec 2018"
    row.cells[2].text = "31 Oct 2024"
    row.cells[3].text = "31 Oct 2027"

    	#doc.add_page_break()
    	#e = datetime.datetime.now()
    	#d=e.strftime("%Y-%m-%d_%H-%M-%S")
    doc.save("Solaris_LLD.docx")
	#startTime = time.time()
        #executionTime = (time.time() - startTime)
        #print('Execution time in seconds: ' + str(executionTime))

else:
	print("template.docx file not found")

