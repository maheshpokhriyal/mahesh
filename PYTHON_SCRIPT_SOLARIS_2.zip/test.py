#!/usr/bin/python3.0
import docx,socket
from docx import Document
import os
import platform
import psutil
import os.path

doc = docx.Document()

zn=os.popen("zoneadm list -vc|grep -v ID|awk '{print $1,$2,$3,$4,$5,$6}'").read().splitlines()
print(zn)

doc.add_heading(' RHEL')
doc_para = doc.add_paragraph()
table = doc.add_table(rows=1, cols=6)
table.style = "Table Grid"
table.allow_autofit = True

hdr_cells = table.rows[0].cells
hdr_cells[0].paragraphs[0].add_run('ID').bold = True
hdr_cells[1].paragraphs[0].add_run('NAME').bold = True
hdr_cells[2].paragraphs[0].add_run('STATUS').bold = True
hdr_cells[3].paragraphs[0].add_run('PATH').bold = True
hdr_cells[4].paragraphs[0].add_run('BRAND').bold = True
hdr_cells[5].paragraphs[0].add_run('IP').bold = True

for item in zn:
    znc = item.split()
    print(znc)
    row_cells = table.add_row().cells
    row_cells[0].text = znc[0]
    row_cells[1].text = znc[1]
    row_cells[2].text = znc[2]
    row_cells[3].text = znc[3]
    row_cells[4].text = znc[4]
    row_cells[5].text = znc[5]
